# Implementation Plan — Rename to Drishti, Apply New Launcher Icon & Fix API Key Issue

Update the application name to **Drishti**, replace the launcher icon with the user-provided walking guide & glowing eye emblem, and fix the "Camera scan fails or says API key required" error by adding in-app API key configuration and robust visual processing.

---

## Proposed Changes

### 1. Rename Application to "Drishti"
- **Platform Metadata (`metadata.json`)**: Update `name` to `"Drishti"`, keeping `"MAJOR_CAPABILITY_SERVER_SIDE_GEMINI_API"`.
- **String Resources (`app/src/main/res/values/strings.xml`)**: Update `app_name` to `"Drishti"`.
- **Gradle Settings (`settings.gradle.kts`)**: Update `rootProject.name` to `"Drishti"`.
- **In-App Branding**: Update header labels and spoken announcements in `MainActivity.kt` and `VisionHomeScreen.kt` to reflect "Drishti".

### 2. Configure Launcher Icon
- Generate the app launcher icon matching the uploaded graphic: A glowing white silhouette of a person with a white walking cane beside a radiant electric-cyan eye on a dark navy/black background (`#0B0F19`).
- Generate `ic_launcher.png` and masked circular `ic_launcher_round.png` across all densities (`mdpi`, `hdpi`, `xhdpi`, `xxhdpi`, `xxxhdpi`).
- Update `ic_launcher_foreground.xml` and `ic_launcher_background.xml` with `#0B0F19`.

### 3. Fix Camera Scan "API Key Required" Bug
- **In-App API Key Configuration**:
  - Add an accessible **"Gemini API Key"** field in the **Accessibility & Settings** screen (`UserSettingsScreen.kt`) allowing users to easily paste or update their Gemini API key directly on device.
  - Show a helpful, accessible one-tap dialog if a scan is attempted without a configured key, giving the user an option to enter their key or test with on-device heuristics.
- **Priority Resolution in `GeminiVisionService`**:
  - Check user-entered key from `PreferencesManager` first; if absent, fall back to `BuildConfig.GEMINI_API_KEY`.
- **On-Device Real-Time Image Heuristics Fallback**:
  - If no API key is available or network fails, provide dynamic real-time frame heuristics (brightness analysis, edge/contrast density detection, and guidance such as "Image captured, lighting adequate, hold steady") so the camera scan never halts with an unhandled failure.

---

## Verification Plan

### Automated Tests
- Run `compile_applet` to ensure full build success.
- Run `gradle :app:testDebugUnitTest` to verify unit and Robolectric tests with the updated "Drishti" app name and new preferences.

### Manual Verification
- Verify launcher icon in mipmap densities.
- Verify that tapping "Scan" with and without custom API keys handles state cleanly, announces status aloud, and allows key entry directly from the UI.
